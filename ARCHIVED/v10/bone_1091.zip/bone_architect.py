# bone_architect.py
# "We shape our buildings; thereafter they shape us." - Churchill

from typing import Tuple, Dict, Any, Optional
from dataclasses import dataclass
from bone_bus import Prisma, MindSystem, PhysSystem, PhysicsPacket
from bone_village import TownHall
from bone_spores import MycotoxinFactory, LichenSymbiont, HyphalInterface, ParasiticSymbiont, MycelialNetwork
from bone_body import BioSystem, MitochondrialForge, EndocrineSystem, MetabolicGovernor, ViralTracer, ThePacemaker
from bone_brain import DreamEngine, ShimmerState, NeuroPlasticity
from bone_personality import LimboLayer
from bone_physics import TheTensionMeter, TheTangibilityGate, TemporalDynamics
from bone_machine import TheCrucible, TheForge, TheTheremin

@dataclass
class SystemEmbryo:
    mind: MindSystem
    limbo: LimboLayer
    bio: BioSystem
    physics: PhysSystem
    shimmer: Any
    is_gestating: bool = True
    soul_legacy: Optional[Dict] = None

class PanicRoom:
    @staticmethod
    def get_safe_physics():
        return PhysicsPacket(
            voltage=5.0,
            narrative_drag=5.0,
            clean_words=["system", "error", "recovery"],
            vector={"STR": 0.5, "VEL": 0.5, "ENT": 0.0},
            counts={"heavy": 0, "kinetic": 0},
            raw_text="[SYSTEM FAILURE: PHYSICS BYPASSED]",
            psi=0.5,
            kappa=0.5,
            flow_state="SAFE_MODE",
            zone="PANIC_ROOM"
        )

    @staticmethod
    def get_safe_bio(previous_state=None):
        base = {
            "is_alive": True,
            "atp": 10.0,
            "chem": {"DOP": 0.0, "COR": 0.0, "OXY": 0.0, "SER": 0.0},
            "logs": [f"{Prisma.RED}BIO FAIL: Triage Protocol Active.{Prisma.RST}"],
            "respiration": "NECROSIS",
            "enzyme": "NONE"
        }

        if previous_state and isinstance(previous_state, dict):
            old_chem = previous_state.get("chemistry", {})
            if old_chem:
                base["chem"]["COR"] = min(0.9, old_chem.get("COR", 0.0))
                base["chem"]["SER"] = max(0.2, old_chem.get("SER", 0.0)) # Administer SSRIs

        return base

    @staticmethod
    def get_safe_mind():
        return {
            "lens": "NARRATOR",
            "role": "The Backup System",
            "thought": "I cannot think clearly, therefore I still am, but barely.",
        }

class BoneArchitect:
    @staticmethod
    def _construct_mind(events, lex) -> Tuple[MindSystem, LimboLayer]:
        _mem = MycelialNetwork(events)
        limbo = LimboLayer()
        _mem.cleanup_old_sessions(limbo)
        mind = MindSystem(
            mem=_mem,
            lex=lex,
            dreamer=DreamEngine(events),
            mirror=TownHall.Mirror(events),
            wise=TownHall.Apeirogon(events),
            tracer=ViralTracer(_mem),
            integrator=TownHall.Sorites(_mem)
        )
        return mind, limbo

    @staticmethod
    def _construct_bio(events, mind, lex) -> BioSystem:
        return BioSystem(
            mito=MitochondrialForge("PENDING_ACTIVATION", events),
            endo=EndocrineSystem(),
            immune=MycotoxinFactory(),
            lichen=LichenSymbiont(),
            gut=HyphalInterface(),
            plasticity=NeuroPlasticity(),
            governor=MetabolicGovernor(),
            shimmer=ShimmerState(),
            parasite=ParasiticSymbiont(mind.mem, lex)
        )

    @staticmethod
    def _construct_physics(events, bio) -> PhysSystem:
        return PhysSystem(
            tension=TheTensionMeter(events),
            forge=TheForge(),
            crucible=TheCrucible(),
            theremin=TheTheremin(),
            pulse=ThePacemaker(),
            gate=TheTangibilityGate(),
            dynamics=TemporalDynamics(),
            nav=TownHall.Navigator(bio.shimmer)
        )

    @staticmethod
    def incubate(events, lex) -> SystemEmbryo:
        if hasattr(events, "set_dormancy"):
            events.set_dormancy(True)
        events.log(f"{Prisma.GRY}[ARCHITECT]: Laying foundations (Dormancy Active)...{Prisma.RST}", "SYS")
        mind, limbo = BoneArchitect._construct_mind(events, lex)
        bio = BoneArchitect._construct_bio(events, mind, lex)
        physics = BoneArchitect._construct_physics(events, bio)
        return SystemEmbryo(
            mind=mind,
            limbo=limbo,
            bio=bio,
            physics=physics,
            shimmer=bio.shimmer,
            is_gestating=True
        )

    @staticmethod
    def awaken(embryo: SystemEmbryo) -> SystemEmbryo:
        events = embryo.bio.mito.events
        load_result = embryo.mind.mem.autoload_last_spore()
        inherited_traits = {}
        inherited_antibodies = set()
        soul_legacy = {}
        if load_result:
            if isinstance(load_result, tuple):
                if len(load_result) >= 1: inherited_traits = load_result[0]
                if len(load_result) >= 2: inherited_antibodies = load_result[1]
                if len(load_result) >= 3: soul_legacy = load_result[2]
            events.log(f"{Prisma.CYN}[ARCHITECT]: Ancestral Spirit detected.{Prisma.RST}", "SYS")
        else:
            events.log(f"{Prisma.WHT}[ARCHITECT]: No ancestors found. A new lineage begins.{Prisma.RST}", "SYS")
        embryo.bio.mito.state.mother_hash = embryo.mind.mem.session_id
        embryo.bio.mito.apply_inheritance(inherited_traits)
        embryo.bio.immune.active_antibodies = inherited_antibodies
        embryo.soul_legacy = soul_legacy
        embryo.is_gestating = False
        events.log(f"{Prisma.GRN}[ARCHITECT]: Embryo viable. Breaking the shell...{Prisma.RST}", "SYS")
        if hasattr(events, "set_dormancy"):
            events.set_dormancy(False)
        return embryo